import {Outlet, useNavigate} from "react-router";
import Sidebar from "./Sidebar";
import Header from "~/Components/Screen/Dashboard/Header";
// @ts-ignore
import { COLORS } from "../../../Constants/Colors";
import {useAppSelector} from "~/Store/hook";
import type { Route } from "./+types/Dashboard";
import {getCookie} from "~/Utils/CookieHandler";
import {useEffect} from "react";
import {useDispatch} from "react-redux";
import {setUser} from "~/Store/Slices/userSlice";


export async function clientLoader({ params }: Route.ClientLoaderArgs) {

    const token = getCookie("token");
    if (!token) {
        return { redirect: '/auth' };
    } else {
        const user = await fetch('http://localhost:3001/users/verify', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                Authorization: `Bearer ${token}`,
            },
        });
        if (!user.ok) {
            return { redirect: '/auth' };
        }
        const userData = await user.json();
        return {user: userData};
    }
}

export default function Dashboard({loaderData}: { clientLoader: Route.ComponentProps }) {
    const user = useAppSelector(state => state.user);
    const nav = useNavigate();
    const dispatch = useDispatch();

    useEffect(() => {
        if (!loaderData.user) {
            nav('/auth');
        } else {
            dispatch(setUser(loaderData.user));
        }
    }, []);

    return (
        <main style={{
            display: "flex",
            maxHeight: '100vh',
        }}>
            <Sidebar />
            <div style={{
                width: "100%",
            }}>
                <Header />
                <div style={{
                    backgroundColor: COLORS.BACKGROUND,
                    width: "100%",
                    maxHeight: 'calc(100vh - 60px)',
                    padding: '20px 20px 0 20px',
                    overflowY: 'scroll',
                }}>
                    <div style={{
                        backgroundColor: 'white',
                        borderRadius: '10px',
                        width: '100%',
                        height: '100%',
                        minHeight: 'calc(100vh - 60px)',
                        paddingBottom: '20px',
                    }}>
                        {user.isAuthenticated && <Outlet />}
                    </div>
                </div>
            </div>
        </main>
    );
}