import {Draw, FavoriteBorder, GridView} from "@mui/icons-material";
import "./Sidebar.css"
// @ts-ignore
import { COLORS } from "../../../Constants/Colors";
import {NavLink, useNavigate} from "react-router";

export default function Sidebar() {
    const nav = useNavigate();

    const sideItems = [
        {
            icon: <GridView />,
            label: "Dashboard",
            link: "/"
        },
        {
            icon: <Draw />,
            label: "Your Forums",
            link: "/your-forums"
        },
        // {
        //     icon: <FavoriteBorder />,
        //     label: "Favourite",
        //     link: "/favourite"
        // }
    ]

    return (
        <div id={"sidebar"} style={{
            width: "250px",
            height: "100vh",
            padding: "20px",
            borderRight: `2px solid ${COLORS.TERTIARY}`,
        }}>
            <div style={{
                height: '100px'
            }} />
            {sideItems.map((item, index) => (
                <NavLink to={item.link} key={index} className={"sidebar-item"} style={{
                    display: "flex",
                    alignItems: "center",
                    cursor: "pointer",
                }}>
                    <div style={{
                        marginRight: "10px",
                    }}>
                        {item.icon}
                    </div>
                    <span style={{
                        fontSize: "16px",
                    }}>{item.label}</span>
                </NavLink>
            ))}
        </div>
    );
}