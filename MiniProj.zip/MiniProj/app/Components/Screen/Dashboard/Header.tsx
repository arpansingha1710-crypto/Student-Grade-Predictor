import { Search } from "@mui/icons-material";
import "./Header.css";


// @ts-ignore
import { COLORS } from "../../../Constants/Colors";

export default function Header() {
    return (
        <div style={{
            height: "60px",
            width: "100%",
            borderBottom: `3px solid ${COLORS.TERTIARY}`,
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            padding: "0 20px",
        }}>
            <div className={"header-search"}>
                <input placeholder={"Search..."}/>
                <Search style={{
                    cursor: 'pointer'
                }} />
            </div>
            <div style={{
                width: '35px',
                height: '35px',
                borderRadius: '50%',
                backgroundColor: 'blue'
            }} />
        </div>
    );
}