import Forum from "../../Items/Forum";
import "./Home.css"
import {useAppDispatch, useAppSelector} from "~/Store/hook";
import {useNavigate} from "react-router";
import {useEffect, useState} from "react";
import {setYourForums} from "~/Store/Slices/yourForumsSlice";

export default function Home() {

    const [forums, setForums] = useState([]);

    const user = useAppSelector(state => state.user);


    useEffect(() => {
            fetch("http://localhost:3001/posts/getRecentPosts", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "Authorization": `Bearer ${user.token}`,
                },
            }).then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            }).then(data => {
                setForums(data.posts);
            }).catch(error => {
                console.error('There was a problem with the fetch operation:', error);
            });

    }, []);

    return (
        <div>
            <p className={"home-section_title"}>Current Trending Forums</p>
            {forums.map((forum, index) => (
                <div key={index} style={{
                    marginBottom: '20px',
                }}>
                    <Forum
                        forum={forum}
                    />
                </div>
            ))}
        </div>
    );
}