import {useNavigate} from "react-router";
import {useState} from "react";
import {setCookie} from "~/Utils/CookieHandler";
import {useAppDispatch} from "~/Store/hook";
import {setUser} from "~/Store/Slices/userSlice";

export default function Login() {
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [error, setError] = useState("");
    const dispath = useAppDispatch();

    const nav = useNavigate();

    const onLogin = async () => {
        if (!email || !password) {
            setError("Please fill in all fields.");
            return;
        }

        const response = await fetch("http://localhost:3001/users/login", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify({email, password}),
        });

        if (response.ok) {
            const data = await response.json();
            setCookie("token", data.user.token, 30);
            dispath(setUser(data.user));
            nav("/");
        } else {
            const errorData = await response.json();
            setError(errorData.error || "Login failed. Please try again.");
        }
    }

    return (
        <div>
            <p style={{
                textAlign: "center",
                fontSize: "1.5rem",
                fontWeight: "bold",
            }}>LOGIN</p>
            <p style={{
                color: "red",
                marginBottom: "20px",
                textAlign: "center",
                fontSize: "0.9rem",
                fontWeight: "bold",
            }}>{error}</p>
            <div className={"form"}>
                <div>
                    <label htmlFor="email">Email</label>
                    <input value={email} onChange={(e) => {
                        setEmail(e.target.value);
                    }} type="email" id="email" name="email" required />
                </div>
                <div>
                    <label htmlFor="password">Password</label>
                    <input value={password} onChange={(e) => {
                        setPassword(e.target.value);
                    }} type="password" id="password" name="password" required />
                </div>
                <button onClick={onLogin}>Login</button>
            </div>
            <p style={{
                marginTop: "20px",
                textAlign: "center",
            }}>Don't already have an account? <span onClick={() => {
                nav("/auth/register")
            }} style={{
                color: "#007BFF",
                cursor: "pointer",
            }}>Create one</span></p>
        </div>
    );
}