import {Outlet} from "react-router";
// @ts-ignore
import {COLORS} from "~/Constants/Colors";
import './Authentication.css'

export default function Authentication() {
    return (
        <main style={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            height: "100vh",
            backgroundImage: `linear-gradient(to bottom, white, white, #97cdff)`,
        }}>
            <div style={{
                border: `1px solid ${COLORS.TERTIARY}`,
                width: "400px",
                borderRadius: "10px",
                borderWidth: "3px",
                padding: "20px 25px"
            }}>
                <Outlet />
            </div>
        </main>
    )
}