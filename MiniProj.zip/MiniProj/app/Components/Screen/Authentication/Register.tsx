import {useNavigate} from "react-router";
import {useState} from "react";

export default function Register() {
    const [name, setName] = useState("");
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [confirmPassword, setConfirmPassword] = useState("");
    const [error, setError] = useState("");

    const nav = useNavigate();

    const onRegister = async () => {
        setError("");

        if (!name || !email || !password || !confirmPassword) {
            setError("All fields are required");
            return;
        } else if (password !== confirmPassword) {
            setError("Passwords do not match");
            return;
        } else if (password.length < 6) {
            setError("Password must be at least 6 characters long");
            return;
        } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
            setError("Invalid email format");
            return;
        }

        try {
            const response = await fetch("http://localhost:3001/users/register", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({ name, email, password }),
            });

            if (!response.ok) {
                const errorData = await response.json();
                setError(errorData.error || "Registration failed");
                return;
            }

            // Redirect to login page on successful registration
            nav("/auth");
        } catch (err) {
            setError("An error occurred during registration");
        }
    }

    return (
        <div>
            <p style={{
                textAlign: "center",
                fontSize: "1.5rem",
                fontWeight: "bold",
            }}>REGISTER</p>
            <p style={{
                color: "red",
                marginBottom: "20px",
                textAlign: "center",
                fontSize: "0.9rem",
                fontWeight: "bold",
            }}>{error}</p>
            <div className={'form'} onSubmit={onRegister}>
                <div>
                    <label htmlFor="name">Name</label>
                    <input value={name} onChange={(e) => {
                        setName(e.target.value);
                    }} type="text" id="name" name="name" required />
                </div>
                <div>
                    <label htmlFor="email">Email</label>
                    <input value={email} onChange={(e) => {
                        setEmail(e.target.value);
                    }} type="email" id="email" name="email" required />
                </div>
                <div>
                    <label htmlFor="password">Password</label>
                    <input value={password} onChange={(e) => {
                        setPassword(e.target.value);
                    }} type="password" id="password" name="password" required />
                </div>
                <div>
                    <label htmlFor="confirmPassword">Confirm Password</label>
                    <input value={confirmPassword} onChange={(e) => {
                        setConfirmPassword(e.target.value);
                    }} type="password" id="confirmPassword" name="confirmPassword" required />
                </div>
                <button onClick={(event) => {
                    onRegister();
                }}>Register</button>
            </div>
            <p style={{
                marginTop: "20px",
                textAlign: "center",
            }}>Already have an account? <span onClick={() => {
                nav("/auth")
            }} style={{
                color: "#007BFF",
                cursor: "pointer",
            }}>Login</span></p>
        </div>
    );
}