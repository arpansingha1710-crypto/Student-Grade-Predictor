import {ChatBubble, ThumbUp} from "@mui/icons-material";

export function Comment({comment}: { comment: { by: string, text: string, likes: number } }) {
    return (
        <div style={{
            marginLeft: "5px",
            border: "1px solid #e0e0e0",
            borderRadius: "15px",
            padding: "10px 10px",
            marginBottom: "10px",
        }}>
            <div style={{
                display: "flex",
                alignItems: "center",
                marginBottom: "8px"
            }}>
                <div style={{
                    width: "35px",
                    height: "35px",
                    borderRadius: "50%",
                    backgroundColor: "#007bff",
                }}/>
                <p style={{marginLeft: "8px", fontWeight: 500}}>{comment.by}</p>
                <div className={"all-stats"}>
                    <div>
                        <p>132</p>
                        <ThumbUp />
                    </div>
                    <div>
                        <p>12</p>
                        <ChatBubble />
                    </div>
                </div>
            </div>
            <p style={{
                marginLeft: "10px"
            }}>{comment.text}</p>
        </div>
    );
}