import {ChatBubble, Close, ThumbUp} from "@mui/icons-material";
import "./Forum.css"
import {useEffect, useState} from "react";
import {Comment} from "~/Components/Screen/Forum/Comment";
import type { Route } from "./+types/Forum";
import {useAppSelector} from "~/Store/hook";

export async function clientLoader({params} : Route.LoaderArgs) {
    return params;
}

export default function Forum({loaderData} : Route.ComponentProps) {
    const [forum, setForum] = useState();

    const user = useAppSelector((state) => state.user);

    useEffect(() => {
        const getPost = async () => {
            const postId = loaderData.id;
            const data = await fetch(`http://localhost:3001/posts/get`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "Authorization": `Bearer ${user.token}`,
                },
                body: JSON.stringify({postId}),
            });

            return await data.json();
        }

        getPost().then((data) => {
            if (data) {
                setForum(data);
            } else {
                console.error("Post not found or error fetching post data.");
            }
        }).catch((error) => {
            console.error("Error fetching post data:", error);
        });
    }, [loaderData]);

    const [comments, setComments] = useState([
        {
            by: "Piyus Kumar",
            text: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.",
            likes: 12,
        },
        {
            by: "John Doe",
            text: "Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.",
            likes: 5,
        },
        {
            by: "Jane Smith",
            text: "Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.",
            likes: 8,
        }
    ]);

    if (!forum) {
        return (
            <main style={{ padding: "20px" }}>
                <p>Loading...</p>
            </main>
        );
    }

    return (
        <main style={{
            padding: "20px 20px 0px 20px"
        }}>
            <p style={{
                fontWeight: 500,
                fontSize: "20px",
                marginBottom: "3px"
            }}>{forum.title}</p>
            <div style={{
                display: "flex",
                alignItems: "center",
                marginLeft: "10px",
            }}>
                <div style={{
                    width: "35px",
                    height: "35px",
                    borderRadius: "50%",
                    backgroundColor: "#007bff",
                }} />
                <p style={{marginLeft: "8px"}}>{forum.by}</p>
            </div>
            <p style={{
                marginTop: "50px",
                whiteSpace: "pre",
            }}>
                {forum.content}
            </p>

            <div id={'tags'}>
                {forum.tags.map((tag, index) => (
                    <div className={"tag"} key={index}>
                        <span>#{tag}</span>
                    </div>
                ))}
            </div>

            <div style={{
                width: "100%",
                height: "3px",
                backgroundColor: "#e0e0e0",
                margin: "20px 0"
            }} />

            <div id={'forum-stats'} className={"all-stats"}>
                <div>
                    <p>132</p>
                    <ThumbUp />
                </div>
                <div>
                    <p>12</p>
                    <ChatBubble />
                </div>
            </div>

            <div>
                <p style={{
                    fontWeight: 500,
                    fontSize: "18px",
                    marginBottom: "10px",
                }}>Comments</p>
                {comments.map((comment, index) => (
                    <Comment key={index} comment={comment} />
                ))}
            </div>
        </main>
    );
}