import { Close } from "@mui/icons-material";
import "./CreateForum.css"
import {useState} from "react";
import {useNavigate} from "react-router";
import {useAppDispatch, useAppSelector} from "~/Store/hook";
import {addToYourForum} from "~/Store/Slices/yourForumsSlice";

export default function CreateForum() {
    const [title, setTitle] = useState("");
    const [description, setDescription] = useState("");
    const [tags, setTags] = useState(["ideas"]);

    const dispatch = useAppDispatch();
    const user = useAppSelector(state => state.user);
    const nav = useNavigate();
    const [error, setError] = useState("");
    const [tagInput, setTagInput] = useState("");

    const onCreateForum = async () => {
        if (!title || !description) {
            setError("Please fill all fields.");
            return;
        }
        if (title.length > 200) {
            setError("Title is too long. Maximum 100 characters.");
            return;
        } else if (description.length > 1000) {
            setError("Description is too long. Maximum 1000 characters.");
            return;
        }

        try {
            const post = await fetch("http://localhost:3001/posts/create", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "Authorization": `Bearer ${user.token}`,
                },
                body: JSON.stringify({
                    title,
                    description,
                    tags,
                }),
            });
            const data = await post.json();
            dispatch(addToYourForum(data))
            nav("/your-forums");
        } catch (err) {
            setError(err.message ?? err.error);
            return;
        }
    };

    return (
        <div style={{
            padding: "0 20px"
        }}>
            <p style={{
                color: 'red',
                fontSize: '18px',
                marginBottom: '10px',
                textAlign: 'center',
            }}>{error}</p>
            <div>
                <div id={"title"}>
                    <input value={title} onChange={(e) => {
                        setTitle(e.target.value);
                    }} type="text" name="title" required placeholder={"Enter Title..."} />
                </div>
                <div id="description" style={{display: 'flex', flexDirection: 'column'}}>
                    <textarea value={description} onChange={(e) => {
                        setDescription(e.target.value);
                    }} name="description" placeholder={"Enter your ideas!"} ></textarea>
                </div>
                <div id={'tags'}>
                    {tags.map((tag, index) => (
                        <div className={"tag"} key={index}>
                            <span>#{tag}</span>
                            <Close style={{
                                color: 'red',
                                cursor: 'pointer'
                            }} onClick={() => [
                                setTags(tags => tags.filter((_, i) => i !== index))
                            ]} />
                        </div>
                    ))}
                    <input type="text" name="tags" required placeholder={"Enter related tags"} value={tagInput} onChange={(e) => {
                        setTagInput(e.target.value);
                    }} onKeyPress={(e) => {
                        if (e.key === 'Enter' && tagInput.trim() !== "") {
                            e.preventDefault();
                            setTags([...tags, tagInput.trim()]);
                            setTagInput("");
                        }
                    }} />
                </div>
                <div style={{
                    display: "flex",
                    justifyContent: "flex-end",
                    marginTop: "20px"
                }}>
                    <button style={{
                        backgroundColor: "#007bff",
                        color: "white",
                        padding: "8px 30px",
                        border: "none",
                        borderRadius: "15px",
                        cursor: "pointer"
                    }} onClick={onCreateForum}>Create Forum</button>
                </div>
            </div>
        </div>
    );
}