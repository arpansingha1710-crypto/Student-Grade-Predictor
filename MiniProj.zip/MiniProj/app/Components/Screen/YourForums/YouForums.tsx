import Forum from "~/Components/Items/Forum";
import {useNavigate} from "react-router";
import {useAppDispatch, useAppSelector} from "~/Store/hook";
import {useEffect} from "react";
import {setYourForums} from "~/Store/Slices/yourForumsSlice";

export default function YouForums() {
    const user = useAppSelector(state => state.user);

    const nav = useNavigate();
    const dispatch = useAppDispatch();
    const forumState = useAppSelector(state => state.yourForums);

    useEffect(() => {
        if (!forumState.requested) {
            fetch("http://localhost:3001/posts/getAllPosts", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "Authorization": `Bearer ${user.token}`,
                },
                body: JSON.stringify({id: user.id})
            }).then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            }).then(data => {
                dispatch(setYourForums(data.posts));
            }).catch(error => {
                console.error('There was a problem with the fetch operation:', error);
            });
        }
    }, []);

    return (
        <main>
            <div style={{
                display: 'flex',
                justifyContent: 'flex-end',
                padding: '20px',
            }}>
                <button onClick={() => {
                    nav('/create-forum');
                }} style={{
                    backgroundColor: '#007bff',
                    color: 'white',
                    padding: '8px 20px',
                    border: 'none',
                    borderRadius: '5px',
                    cursor: 'pointer',
                    marginBottom: '20px',
                }}>Create Forum</button>
            </div>

            {forumState.yourForums.map((forum, index) => (
                <div key={index} style={{
                    marginBottom: '20px',
                }}>
                    <Forum
                        forum={{by: user.name, ...forum}}
                    />
                </div>
            ))}
        </main>
    );
}