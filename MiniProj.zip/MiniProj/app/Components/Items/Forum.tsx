import {ChatBubble, Comment, ThumbUp} from "@mui/icons-material";
import "./Forum.css"
// @ts-ignore
import { COLORS } from "../../Constants/Colors";
import {useNavigate} from "react-router";

export default function Forum({forum}: {forum: {by: string, id: string, title: string, content: string, tags: string[]}}) {

    const nav = useNavigate();

    return (
        <div onClick={() => [
            nav(`/forum/${forum.id}`)
        ]} style={{
            border: `2px solid ${COLORS.TERTIARY}`,
            padding: '10px',
            margin: '10px 30px',
            borderRadius: '10px',
            cursor: 'pointer',
        }}>
            <div style={{
                display: 'flex',
                alignItems: 'center',
                marginBottom: '5px',
            }}>
                <div style={{
                    width: '30px',
                    height: '30px',
                    borderRadius: '50%',
                    backgroundColor: 'blue',
                    display: 'inline-block',
                    marginRight: '10px',
                }} />
                <p>{forum.by}</p>
            </div>
            <div style={{display: 'flex', alignItems: 'center', marginBottom: '10px'}}>
                <p style={{
                    fontWeight: 500,
                }}>{forum.title}</p>
                <div style={{display: 'flex', marginLeft: '20px', alignItems: 'center'}}>
                    {forum.tags.map((tag, index) => (
                        <p key={index} className={"forum-tag"}>{tag}</p>
                    ))}
                </div>
            </div>
            <div style={{
                display: 'flex',
                justifyContent: 'space-between',
            }}>
                <p style={{
                    color: `${COLORS.TERTIARY_TEXT}`,
                    width: '500px',
                    textWrap: 'nowrap',
                    overflow: 'hidden',
                    textOverflow: 'ellipsis',
                }}>{forum.content}</p>
                <div style={{display: 'flex'}}>
                    <div className={"forum-icon"}>
                        <p style={{marginLeft: '5px'}}>12</p>
                        <ThumbUp style={{color: COLORS.TERTIARY}} />
                    </div>
                    <div className={"forum-icon"}>
                        <p style={{marginLeft: '5px'}}>5</p>
                        <ChatBubble style={{color: COLORS.TERTIARY}} />
                    </div>
                </div>
            </div>
        </div>
    );
}