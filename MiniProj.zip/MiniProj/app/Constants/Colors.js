export const COLORS = {
    BACKGROUND: '#f0f0f0',
    TERTIARY_TEXT: '#5e5e5e',
    TERTIARY: '#d8d8d8',
}