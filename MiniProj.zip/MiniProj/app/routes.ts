import {type RouteConfig, index, route, layout} from "@react-router/dev/routes";

export default [
    layout("Components/Screen/Dashboard/Dashboard.tsx", [
        index("./Components/Screen/Home/Home.tsx"),
        route("/your-forums", "./Components/Screen/YourForums/YouForums.tsx"),
        route("/create-forum", "./Components/Screen/CreateForum/CreateForum.tsx"),
        route("/forum/:id", "./Components/Screen/Forum/Forum.tsx")
    ]),
    route("/auth", "./Components/Screen/Authentication/Authentication.tsx", [
        index("Components/Screen/Authentication/Login.tsx"),
        route("/auth/register", "./Components/Screen/Authentication/Register.tsx"),
    ]),
] satisfies RouteConfig;
