//userSlice

import {createSlice, type PayloadAction} from '@reduxjs/toolkit';

interface UserState {
    id: string;
    name: string;
    email: string;
    token: string;
    isAuthenticated: boolean;
}

const initialState: UserState = {
    id: '',
    name: '',
    email: '',
    token: '',
    isAuthenticated: false,
};

const userSlice = createSlice({
    name: 'user',
    initialState,
    reducers: {
        setUser: (state, action: PayloadAction<{id: string, name: string; email: string, token: string }>) => {
            state.name = action.payload.name;
            state.email = action.payload.email;
            state.id = action.payload.id;
            state.token = action.payload.token;
            state.isAuthenticated = true;
        },
        clearUser: (state) => {
            state.name = '';
            state.email = '';
            state.isAuthenticated = false;
        },
    },
});

export const { setUser, clearUser } = userSlice.actions;
export default userSlice.reducer;