import { createSlice } from '@reduxjs/toolkit';

interface _YourForumsState {
  id: string;
  text: string;
  description: string;
  tags: string[];
  author_id: string;
}

interface YourForumsState {
  yourForums: _YourForumsState[];
  requested: boolean,
}

const initialState: YourForumsState = {
  yourForums: [],
  requested: false,
}

const yourForumsSlice = createSlice({
  name: 'yourForums',
  initialState,
  reducers: {
    setYourForums: (state, action) => {
      state.yourForums = action.payload;
      state.requested = true;
    },
    addToYourForum: (state, action) => {
      state.yourForums = [action.payload, ...state.yourForums];
      state.requested = true;
    },
  },
});

export const { setYourForums, addToYourForum } = yourForumsSlice.actions;
export default yourForumsSlice.reducer;